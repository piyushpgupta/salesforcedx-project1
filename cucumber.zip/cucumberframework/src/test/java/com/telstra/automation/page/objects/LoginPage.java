/*package com.telstra.automation.page.objects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage {
	
	  public static By txt_username=By.id("username");
	  public static By txt_password=By.id("password");
	  public static By btn_login=By.id("Login");
		

}
*/