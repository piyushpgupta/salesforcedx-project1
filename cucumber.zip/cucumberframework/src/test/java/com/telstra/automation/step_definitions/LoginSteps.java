/*package com.telstra.automation.step_definitions;

import java.util.ArrayList;

import com.telstra.automation.page.actions.LoginActions;
import com.telstra.automation.page.objects.PageObject;
import com.telstra.automation.utility.BrowserUtility;
import com.telstra.automation.utility.ExcelUtility;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.When;

public class LoginSteps extends PageObject {
	
	@Given("^User navigate to \"([^\"]*)\" application url with user profile as \"([^\"]*)\"$")
	public void user_navigate_to_application_url_with_user_profile_as(String arg1, String arg2) throws Throwable {
		PageObject.browserLaunch();
	
		String env = "linus";
		System.out.println("check"+arg2);
		ArrayList<String> logdetails=ExcelUtility.getCellData(env, arg2);
		//BrowserUtility.urlLaunch(url);
		//ArrayList<String> logdetails=ExcelUtility.loginData; 
		System.out.println("Hi"+logdetails);
		LoginActions.loginToApplication(logdetails.get(0).trim(),logdetails.get(1).trim(),logdetails.get(2).trim());//ExcelUtility.loginData.get(0), ExcelUtility.loginData.get(1), ExcelUtility.loginData.get(2)
		//.loginToApplication(userName, pwd, );
	    
	}

	

	@When("^User load test data for \"([^\"]*)\" scenario from \"([^\"]*)\" table$")
	public void user_load_test_data_for_scenario_from_table(String arg1, String arg2) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}

	@When("^Using App Launcher user search for \"([^\"]*)\" and click on the result link$")
	public void using_App_Launcher_user_search_for_and_click_on_the_result_link(String arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	   // throw new PendingException();
	}

	@When("^User clicks on New button to create new lead$")
	public void user_clicks_on_New_button_to_create_new_lead() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    //throw new PendingException();
	}


}
*/