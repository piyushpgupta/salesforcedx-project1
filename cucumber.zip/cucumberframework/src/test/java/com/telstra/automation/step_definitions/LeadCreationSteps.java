/*package com.telstra.automation.step_definitions;

import java.io.IOException;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.telstra.automation.page.actions.HomeActions;
import com.telstra.automation.page.actions.LeadActions;
import com.telstra.automation.page.actions.LoginActions;
import com.telstra.automation.page.objects.LoginPage;
import com.telstra.automation.page.objects.PageObject;
import com.telstra.automation.utility.Utility;
import com.telstra.automation.page.objects.HomePage;
import com.telstra.automation.page.objects.LeadPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LeadCreationSteps extends PageObject{
	private static final Logger LOG = LoggerFactory.getLogger(LeadCreationSteps.class);
	String timeStramp=Utility.timeStramp();
	String LeadName;
	
	@When("^Using App Launcher user search for \"([^\"]*)\" and click on the result link$")
	public void using_App_Launcher_user_search_for_and_click_on_the_result_link(String appName) throws Throwable {
		HomeActions.selectAppFromAppLauncher(appName);
	}

	@When("^User clicks on New button to create new lead$")
	public void user_clicks_on_New_button_to_create_new_lead() throws Exception {
		//Hooks.stepRecordHook("Navigated to Leads page");
		LeadActions.click_NewButtonforLeadCreation();
	}

	@When("^User selects Enterprise and click on Next button$")
	public void user_selects_Enterprise_and_click_on_Next_button() throws Throwable {
		LeadActions.select_Enterprise();
		
	}
	
	@When("^User enters all the details required to create a new lead$")
	public void user_enters_all_the_details_required_to_create_a_new_lead() throws Exception {
		LeadActions.enter_LeadCreationDetails(timeStramp);
		//Hooks.stepRecordHook("Entered lead creation details");
	}

	@When("^User clicks on Save button to create Lead$")
	public void user_clicks_on_Save_button_to_create_Lead() throws Exception {
		//Hooks.stepRecordHook("Clicking on save button");
		LeadActions.click_CreateSaveLeadButton();
	}

	@Given("^User get the lead name$")
	public void User_get_the_lead_name() throws Exception {
		LeadName= LeadActions.getLeadName();
	}
	
	@Given("^User logout from the application$")
	public void user_logout_from_the_application() throws Throwable {
	    LeadActions.click_logOut();
	}
	
	@When("^Selects the dropdown next to the Recently viewed$")
	public void selects_the_dropdown_next_to_the_Recently_viewed() throws Throwable {
		LeadActions.clicksOnDD_nextToRecentlyViewed();
	}
	
	@When("^User clicks on \"([^\"]*)\" link$")
	public void user_clicks_on_link(String LeadName) throws Throwable {
		LeadActions.clicksOnLink__DD_nextToRecentlyReviewd(LeadName);
	}
	
	@When("^User clicks on the Lead Name$")
	public void user_clicks_on_the_Lead_Name() throws Throwable {
		LeadActions.clickOnCreatedDate();
		System.out.println("TEst Load");
		click(LeadPage.queue_leadName(LeadName));
	}

	@When("^User clicks on Change Owner button$")
	public void user_clicks_on_Change_Owner_button() throws Throwable {
		LeadActions.clicksOnChangeOwnerButton();
	}

	@When("^User enters the \"([^\\\"]*)\" new Owner$")
	public void user_enters_the_new_Owner(String Owner) throws Throwable {
		LeadActions.enterNewOwner(Owner);
	}

	@When("^User enters the \"([^\\\"]*)\" Queue$")
	public void user_enters_the_Queue(String Queue) throws Throwable {
		LeadActions.enterNewQueue(Queue);
	}
	
	@When("^User clicks on Submit button$")
	public void click_on_Submit_button() throws Throwable {
		LeadActions.click_SubmitButton();
	}
	
	@When("^User clicks on Convert button$")
	public void click_on_Convert_button() throws Throwable {
		LeadActions.click_ConvertButton();
	}
	
	@When("^User clicks on Clone button$")
	public void click_on_Clone_button() throws Throwable {
		LeadActions.click_CloneButton();
	}
	
	@When("^User clicks on Save button$")
	public void click_on_Save_button() throws Throwable {
		LeadActions.click_SaveButton();
	}

	
	@When("^User enters all the details required to convert a lead$")
	public void user_enters_all_the_details_required_to_convert_a_lead() throws Throwable {
		LeadActions.ConvertLead(); 
		Thread.sleep(5000);
	}
	
	@When("^User finally converts the lead$")
	public void user_finally_converts_the_Lead() throws Throwable {
		LeadActions.ConvertBtntoSave();
		
	}
	
	@When("^User clicks on dropdown to change to queue$")
	public void user_clicks_on_dropdown_to_change_to_queue() throws Throwable {
		LeadActions.clicksOnDropdownTOChangeQueue();
	}
	
	@When("^User enters the middle name$")
	public void user_enters_the_middle_name() throws Throwable {
		LeadActions.enterMiddleName();
	}
	
	
	@When("^User selects the Don't create an Opportunity checkbox$")
	public void User_selects_the_create_Opportunity_checkbox() throws Throwable {
		LeadActions.click_Opportunity_checkbox();
	}
	
	@Then("^User verifies success message and newly created lead$")
	public void user_verifies_success_message_and_newly_created_lead() {
		LeadActions.verify_LeadCreationSuccessMsg();
		//Hooks.stepRecordHook("Lead Created successfully");
	}
}
	@When("^User selects existing Lead on the page$")
	public void user_selects_existing_Lead_on_the_page() throws Throwable {
		LeadActions.SelectLead();
	    
	}

	@When("^User clicks on Convert button to convert lead$")
	public void user_clicks_on_Convert_button_to_convert_lead() throws Throwable {
		Hooks.stepRecordHook("Before first convert lead click");
		LeadActions.Btn_ConvertLead();
		Hooks.stepRecordHook("After first convert lead click");
		
	}

	

	@When("^User clicks on Convert button to convert a Lead$")
	public void user_clicks_on_Convert_button_to_convert_a_Lead() throws Throwable {
		Hooks.stepRecordHook("Before second convert lead click");
		LeadActions.ConvertBtntoSave();
		Hooks.stepRecordHook("After second convert lead click");
	    
	}

	@Then("^User verifies success message for lead conversion$")
	public void user_verifies_success_message_for_lead_conversion() throws Throwable {
		LeadActions.verify_LeadConvertMessage();
		Hooks.stepRecordHook("Lead conversion success message");
		
		//HomeActions.searchInSalesforce("AjayFName LName");
		//LOG.info("Performing global search for Contact AjayFName LName..");	
		//HomeActions.SearchResultClick();
		//LOG.info("Clicked on global search result..");
		
		//ContactsActions.btn_contactdelete();
		//Hooks.stepRecordHook("Converted Contact Deleted successfully");
	    
	}
	
	@Given("^User click on the Leads object$")
	public void user_click_on_the_Leads_object() throws Throwable {
		HomeActions.clickOnMoreBtn();
		HomeActions.Leads_tab_fromMoreDD();
	}

	@Given("^Add lead to existing campaign$")
	public void add_lead_to_existing_campaign() throws Throwable {
		LeadActions.clickOnAddTocampaign();
		LeadActions.addCampToLead(timeStramp);
	}
	@Given("^close the Lead Conversation window$")
	public void close_the_Lead_Conversation_window() throws Throwable {
		LeadActions.closeLeadWindow();
	}
	@Then("^Campaign Source field should be added Campaign$")
	public void campaign_Source_field_should_be_added_Campaign() throws Throwable {
		OpportunityActions.clickOnOppt(timeStramp);
		OpportunityActions.clickDetailsTab();
		Hooks.stepRecordHook("Oppt details tab");
		OpportunityActions.verifyPrimaryCampaignSource();
		
	}
	
	@And("^User selects All Open Leads from dropdown$")
	public void user_selects_All_Open_Leads_from_dropdown() throws Throwable {
		LeadActions.clickOnLeadsDD_nextToRecentlyViewed();
		LeadActions.clickAllOpenLeads_ddSelection();
		
	}
	@And("^Select the first Lead from Lead list$")
	public void select_the_first_Lead_from_Lead_list() throws Throwable {
		LeadActions.clickOnFirstLead_FromOpenLeadsList();
	}
	
	@When("^User a creats a lead using API in Admin login$")
	public void user_a_creats_a_lead_using_API_in_Admin_login() throws Throwable {
	  
	}

	@When("^User selects Telstra Enterprise Leads from drop down next to Recently Viewed$")
	public void user_selects_from_drop_down_next_to_Recently_Viewed() throws Throwable {
		LeadActions.selectTelestraEntLeads();
	}

	@When("^clicks on the Inbound Web Lead Eloqua lead$")
	public void clicks_on_the_Inbound_Web_Lead_Eloqua_lead() throws Throwable {
		LeadActions.clickOnInboundWebLeadEloquaRecord();
	}
	
	@When("^get the Lead Name$")
	public void get_the_Lead_Name() throws Throwable {
		LeadActions.getLeadName();
	}


	@Then("^Verify Maxim ID and Maxim Lead Status pick list values$")
	public void verify_Maxim_ID_and_Maxim_Lead_Status_pick_list_values() throws Throwable {
		LeadActions.clickOnEditBtn();
		LeadActions.verifyMaximumLeadStatusFieldPickListValues();
	}

	@When("^Maxim Lead Status pick list value selected as Converted and save it$")
	public void maxim_Lead_Status_pick_list_value_as_selected_as_Converted_and_save_it() throws Throwable {
		LeadActions.enterMaximStatusDDvalue_NotConvertedStatus();
	}

	@Then("^Error message should display$")
	public void error_message_should_display() throws Throwable {
		LeadActions.verifyErrorMsgWhenNotCompleteMaximumId();
	}

	@Then("^Lead record is filtered out from the Lead queue list Telstra Enterprise Leads$")
	public void the_record_is_filtered_out_from_the_Lead_queue_list() throws Throwable {
		LeadActions.updateMaxLeadStatusDDfield();
		//HomeActions.clickOnMoreBtn();
		//HomeActions.Leads_tab_fromMoreDD();
		HomeActions.selectAppFromAppLauncher("Leads");
		LeadActions.selectTelestraEntLeads();
		LeadActions.verifyLeadQueueListAfterEnteredMaxLeadStatus();
		
	}
	
}


*/