/*package com.telstra.automation.utility;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class Utility {

	public static String timeStramp() {
		String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
		return timeStamp;
	}
	public static String currentDate(String dateFormat) {
		Date myDate = new Date();
		SimpleDateFormat sm = new SimpleDateFormat(dateFormat);
		String strDate = sm.format(myDate);
		return strDate;
	}
	
}
*/