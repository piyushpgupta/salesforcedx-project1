/*package com.telstra.automation.utility;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class BrowserUtility {

	static WebDriver driver;
	public static WebDriver browserLaunch()
	{
		
	driver = new ChromeDriver();
	return driver;
		
	}
	
	public static void urlLaunch(String url)
	{
		
	driver.get(url);
		
	}
	
	
	
}
*/