/*package com.telstra.automation.page.objects;
*//**
 * Author : Ajay Pande
 * ID : D797548
 * Email : Ajay.Pande@team.telstra.com
 *//*
import org.openqa.selenium.By;

public class HomePage {
	 //app Launcher
    //public static By link_appLauncher=By.xpath(".//*[@id='oneHeader']/div[3]/one-appnav/div/div/div/nav/one-app-launcher-header/button");
	public static By link_appLauncher=By.xpath("//one-app-launcher-header/button");
	public static By appLaunhcer_searchField=By.xpath(".//input[contains(@placeholder,'or item')]");
    public static By appLaunhcer_appLink=By.xpath(".//a[contains(@title,'AppLink')]");

    public static By link_appLauncher_new=By.xpath(".//*[title='Search Salesforce']");
    
    //New layout
    public static By dd_optyMenu = By.xpath(".//*[@id='oneHeader']/div[3]/one-appnav/div/one-app-nav-bar/nav/ul/li[3]/one-app-nav-bar-item-dropdown/div/one-tmp-button-menu/button");
    public static By pageLayout_new=By.xpath(".//*[@id='oneHeader']");    		
    //public static By link_newOpty = By.xpath(".//*[@id='oneHeader']/div[3]/one-appnav/div/one-app-nav-bar/nav/ul/li[3]/one-app-nav-bar-item-dropdown/div/one-tmp-button-menu/div/one-tmp-menu-item[1]/a"); 

    //classic layout
    public static By classic_link_userNavigationMenu=By.id("userNavButton");
    public static By classic_link_logout=By.linkText("Logout");
    public static By classic_SFDC_log=By.xpath(".//*[@id='phHeaderLogoImage']");
    
    //public static By link_Opty_classic=By.xpath(".//*[@id='Opportunity_Tab']/a");
    //public static By link_Opty_classic=By.xpath(".//*[@id='oneHeader']/div[3]/one-appnav/div/one-app-nav-bar/nav/ul/li[1]/a/span");
    public static By click_applauncher = By.xpath(".//button[@class='slds-button']");
    public static By link_Opty_classic=By.xpath("(//span[text() = 'Opportunities'])[1]");
    
    //logout lightning
    public static By hometab=By.xpath(".//span[text()='Home']");
    public static By link_userNavigationMenu=By.xpath(".//*[@id='oneHeader']/div[2]/span/ul/li[9]/button");
    public static By link_logout=By.xpath(".//a[text()='Log Out']");
    
    //Lightning layout
    public static By link_Accounts=By.xpath("//*[@id='oneHeader']/div[3]/one-appnav/div/one-app-nav-bar/nav/ul/li[2]/a/span");
    public static By link_Contacts=By.xpath(".//li/a/span[text()='Contacts']");
    
  
    //public static By link_LogouT=By.xpath("//a[contains(@href, '/secur/logout.jsp')])[2]");
    public static By app_console=By.xpath(".//*[@id='oneHeader']/div[3]/one-appnav/div/div/div/nav/one-app-launcher-header/button");
    
    public static By opportunity_tab_lightning=By.xpath("//a[@title='Opportunities']");
    

    public static By Search_Salesforce=By.xpath("//header[@id='oneHeader']/div[2]/div[2]/div/div/div[2]/div[2]/div/input");
    public static By matched_search_result=By.xpath("//header[@id='oneHeader']/div/div/div/div/div/div/div/div/div/ul/li[2]");
    public static By select_search_result=By.xpath("//header[@id='oneHeader']//div/div/div/div/div/div/div/div/div/ul/li[3]");
    
    
    public static By link_profileIcon=By.className("profileTrigger circular");
    public static By link_switchToClassic=By.linkText("Switch to Salesforce Classic");
    
    //Below changes made by the Kishore
 // public static By opportunity_tab_lightning_new = By.xpath("//a[@title='Opportunities']");
    public static By link_Accounts_new=By.xpath("//a[@title='Accounts']");
    public static By link_campaign=By.xpath("//a[@title='Campaigns']");
    public static By link_Calendar=By.xpath("//a[@title='Calendar']");
    public static By link_Leads=By.xpath("//a[@title='Leads']");
    public static By SearchResultCLick=By.xpath(".//*[@id='oneHeader']/div[2]/div[2]/div/div/div[2]/div[2]/div/div/div[2]/ul/li[2]");
    public static By btn_More=By.xpath("//span[text()='More']/parent::a");
    public static By link_Leads_fromMoreDD=By.xpath("(//a[@href='/one/one.app#/sObject/Lead/home'])[last()]");
    public static By link_Cases_fromMoreDD=By.xpath("(//a[@href='/one/one.app#/sObject/Case/home'])[last()]");
    public static By btn_GlobalQuickAction=By.xpath("//a[@class='globalCreateTrigger']");
    
    
    
    public static By searchedItem(String item) {
	    By link_item =By.xpath("(//a[contains(@title,'"+item+"')])[last()]");
	    return link_item;
	}
    
    public static By txt_profileName=By.xpath("(//h1[@class='profile-card-name']/a[@class='profile-link-label'])[last()]");
    public static By link_Chatter_fromMoreDD=By.xpath("(//a[@href='/one/one.app#/chatter'])[last()]");
    public static By link_DSR_fromMoreDD=By.xpath("(//a[@href='/one/one.app#/sObject/Deal_Support_Request__c/home'])[last()]");
    
    //*******************	CALMS Classic View Locators		********************//
    public static By Agreements=By.xpath(".//a[@title='Agreements Tab']");
    public static By Templates=By.xpath(".//a[@title='Templates Tab']");
    public static By All_tabs=By.xpath(".//*[@id='AllTab_Tab']/a/img");
    public static By Cases=By.xpath(".//a/img[@title='Cases']");
    public static By Funds=By.xpath(".//a/img[@title='Funds']");
    public static By All_btn=By.xpath(".//input[@title='Go!']");
    public static By New_btn=By.xpath(".//input[@title='New']");
    
    
    public static By link_Coin_fromMoreDD=By.xpath("(//a[@href='/lightning/n/COIN2'])[last()]");
    public static By link_Groups_fromMoreDD=By.xpath("(//a[@href='/lightning/o/CollaborationGroup/home'])[last()]");
    public static By link_NewOpportunity_fromGlobalQuickAction=By.xpath("//a[@title='New Opportunity']");
    public static By Search_global_contact=By.xpath(".//input[@title='Search Contacts and more']");
    public static By Search_global_result=By.xpath(".//div[2]/div[2]/div/div[2]/div/div[2]/div[2]/div/div/div[2]/ul/li[3]");
    public static By Search_global_account=By.xpath(".//input[@title='Search Accounts and more']");
    public static By Search_global_opportunity=By.xpath(".//input[@title='Search Opportunities and more']");
}
*/