/*package com.telstra.automation.page.actions;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.telstra.automation.page.objects.LoginPage;
import com.telstra.automation.page.objects.PageObject;

public class LoginActions extends PageObject{

//	static WebDriver driver;
	
	
	public static WebDriver browserLaunch()
	{
	
	driver = new ChromeDriver();
	return driver;
		
	}
	
	public static void loginToApplication(String org, String userName, String pwd ) throws IOException {
		//driver = new ChromeDriver();
		driver.get(org);
		clearEnterText(LoginPage.txt_username, userName);
		System.out.println("user"+userName);
		//driver.findElement(By.id("username")).sendKeys(userName);
		//type(LoginPage.txt_username,userName);
	    driver.manage().timeouts().implicitlyWait(50, TimeUnit.SECONDS);
	    clearEnterText(LoginPage.txt_password, pwd);
	    System.out.println("passsowrd"+pwd);
		click(LoginPage.btn_login);
		//driver.findElement(By.id("Login")).click();
		
	}
	

}                             */