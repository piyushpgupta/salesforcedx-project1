/*package com.telstra.automation.page.objects;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.TimeoutException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class PageObject {

	private static final long DRIVER_WAIT_TIME = 60;
	private static final Logger LOG = LoggerFactory.getLogger(PageObject.class);
	public static WebDriver driver;
	public static WebElement element;
	//public static Properties OR=new Properties();
	//public static FileInputStream fis;
	
	public static WebElement waitForElement(By by) {
		WebDriverWait w = new WebDriverWait(driver, 60);
		w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(by));
		element = driver.findElement(by);
		return element;
	}
	
	public static WebDriver browserLaunch()
	{
		
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	return driver;
	
	}
	public static void click(By by) throws IOException {
		
		waitForElement(by).click();;
		
		fis=new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\properties\\.properties");
		OR.load(fis);
		
		if(locator.contains("XPATH")) {
			System.out.println("xpath");
		
			driver.findElement(By.xpath(OR.getProperty(locator))).click();
		}
		
		else if(locator.contains("ID")) {
			System.out.println("id");
			driver.findElement(By.id(OR.getProperty(locator))).click();
		}
	}
	
	public static void clearEnterText(By by, String value) {
	     
		waitForElement(by).sendKeys(value);
        //waitForExpectedElement(by).sendKeys(inputText);
        //highLightElement(by);
        
    }
	 public static WebDriver switchtoDefault()
	    {
	    	return driver.switchTo().defaultContent();
	    }
	
	 public static void implicitwait(){
	    	driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    }
	 
	 public static boolean isElementPresent(final By by) {
	        try {
	            new WebDriverWait(driver, DRIVER_WAIT_TIME).until(ExpectedConditions.presenceOfElementLocated(by));

	        } catch (TimeoutException exception) {
	            LOG.info(exception.getMessage());
	            return false;
	        }
	        return true;
	    }
public static void type(String locator,String value, String filename) throws IOException {
		
	fis=new FileInputStream(System.getProperty("user.dir")+"\\src\\test\\resources\\properties\\"+filename+".properties");
	OR.load(fis);
	if(locator.contains("XPATH")) {
		System.out.println("xpath");
		driver.findElement(By.xpath(OR.getProperty(locator))).sendKeys(value);;
	}
	
	else if(locator.contains("ID")) {
		System.out.println("id");
		driver.findElement(By.id(OR.getProperty(locator))).sendKeys(value);;
	}
		
	}
	 
	 public static String getText(By by) {
	     
			String text =waitForElement(by).getText();
			return text;
			
	 }
	 
	 public static boolean isDisplayed_withoutTimeWait(By by) {
	     return driver.findElement(by).isDisplayed();
		
	 }
}
*/