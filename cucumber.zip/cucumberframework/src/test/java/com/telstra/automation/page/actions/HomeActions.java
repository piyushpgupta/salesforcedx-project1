/*package com.telstra.automation.page.actions;

import com.telstra.automation.page.objects.HomePage;
import com.telstra.automation.page.objects.LoginPage;
import com.telstra.automation.page.objects.PageObject;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.io.IOException;

import org.openqa.selenium.By;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class HomeActions extends PageObject {

	private static final Logger LOG = LoggerFactory.getLogger(HomeActions.class);

	public static void verifyHomePage() throws InterruptedException {
		//waitForPageLoad();
		//waitForExpectedElement(HomePage.link_appLauncher);
		
		 //D797548 Ajay
		 //commenting below code as Debanga is going to create separate method to verify Classic home page 
		String title="";
		if(isElementPresent(HomePage.link_appLauncher)||isElementPresent(HomePage.Agreements))
		{
			//assertTrue(title.contains("Salesforce"));
			//assertTrue(isElementPresent(HomePage.pageLayout_new));
			LOG.info("Lightning View is opened and verified");	
		}
		else if (title.contains("Unlimited Edition"))
		{
			assertEquals(title, "Salesforce - Unlimited Edition");
			assertTrue(isElementPresent(HomePage.Agreements));
			LOG.info("Classic View is opened and verified");
		}
		else{
			assertTrue(false);
			LOG.info("Home Page cannot be verified");
		}
	}
	public static void verifyClassicHomePage() throws InterruptedException {
		waitForPageLoad();
		waitForExpectedElement(HomePage.classic_SFDC_log);
	}

	public static void verifyHomePage_LoginLink() {
		waitForPageLoad();
		if (!isElementPresent(HomePage.link_userNavigationMenu)) 
		{
			
		}
	}

	public static void clickCreateOpportunity() {
		if (isElementPresent(HomePage.click_applauncher)) {

			click(ProductBasketPage.click_applauncher);
		}
		click(HomePage.link_Opty_classic);
	}

	public static void clickAccountsLinkLightning() {
		click(HomePage.link_Accounts_new);
		waitForPageLoad();
	}

	public static void clickContacts() {
		click(HomePage.link_Contacts);
		waitForPageLoad();
	}

	public static void clickAppConsole() throws IOException {
		click(HomePage.app_console);
	}

	public static void logout_lightning() {
		LOG.info("Logging out from the application");
		click(HomePage.link_userNavigationMenu);
		click(HomePage.link_logout);
		waitForPageLoad();
		waitForExpectedElement(LoginPage.txt_username);
	}

	public static void opprotunity_tab_lightning() throws InterruptedException {
		waitForExpectedElement(HomePage.opportunity_tab_lightning);
		Thread.sleep(2000);
		click(HomePage.opportunity_tab_lightning);
		waitForPageLoad();
		Thread.sleep(3000);
	}
    public static void searchInSalesforce(String text) {
    	waitForPageLoad();
    	switchtoDefault();
    	waitForExpectedElement(HomePage.Search_Salesforce);
    	clearEnterText(HomePage.Search_Salesforce, text);
		waitForPageLoad();
	}

	public static void clicksearchresult() {
		waitForPageLoad();
		click(HomePage.matched_search_result);
	}

	public static void selectAppFromAppLauncher(String appName) throws Throwable {
		Thread.sleep(9000L);
		switchtoDefault();
		click(HomePage.link_appLauncher);
		Thread.sleep(7000);
		clearEnterText(HomePage.appLaunhcer_searchField, appName);
		click(By.xpath(".//a[contains(@title,'" + appName + "')]/span/span/mark"));
		//waitForPageLoad();
	}

	public static void clickCalenderLinkLightning() {
		click(HomePage.link_Calendar);
	}

	public static void Leads_tab() throws IOException {
		click(HomePage.link_Leads);
	}

	public static void SearchResultClick() throws InterruptedException {
		Thread.sleep(5000);
		click(HomePage.matched_search_result);
		//select_search_result
	//}

	public static void clickOnMoreBtn() {
		click(HomePage.btn_More);
	}

	public static void Leads_tab_fromMoreDD() {
		click(HomePage.link_Leads_fromMoreDD);
	}

	public static void Campaigns_tab_lightnining() throws InterruptedException {
		click(HomePage.link_campaign);
		Thread.sleep(3000);
	}

	public static void Cases_tab_lightnining() throws InterruptedException {
		click(HomePage.link_Cases_fromMoreDD);
		Thread.sleep(2000);
	}

	public static void clickOnGlobalQuickAction() throws InterruptedException {
		click(HomePage.btn_GlobalQuickAction);
		Thread.sleep(2000);
	}

	public static void clickOnSearchedItem(String item) throws InterruptedException {
		Enter_KeyboardFunctionality();
		Thread.sleep(3000);
		waitForExpectedElement(HomePage.searchedItem(item));
		click(HomePage.searchedItem(item));
		Thread.sleep(2000);
	}

	public static String getProfileName() throws InterruptedException {
		Thread.sleep(3000);
		click(HomePage.link_userNavigationMenu);
		Thread.sleep(3000);
		String profileName = getText(HomePage.txt_profileName);
		LOG.info("Logged user Name" + profileName);
		return profileName;
	}

	public static void Chatter_tab_lightnining() throws InterruptedException {
		click(HomePage.link_Chatter_fromMoreDD);
		Thread.sleep(3000);
	}

	public static void DSR_tab_lightnining() throws InterruptedException {
		click(HomePage.link_DSR_fromMoreDD);
		Thread.sleep(3000);
	}

	*//**
	 * CALMS actions on Salesforce classic 
	 *//*
	
	public static void click_on_Agreements_tab()
	{
	waitForPageLoad();
	click(HomePage.Agreements);
	LOG.info("Clicked on Agreements");
	}
	
	public static void click_on_Templates_tab()
	{
	waitForPageLoad();
	click(HomePage.Templates);
	LOG.info("Clicked on Templates");
	}
	
	public static void click_on_Cases_tab()
	{
	waitForPageLoad();
	click(HomePage.All_tabs);
	waitForExpectedElement(HomePage.Cases);
	click(HomePage.Cases);
	LOG.info("Clicked on Cases");
	}
	
	public static void click_on_Funds_tab()
	{
	waitForPageLoad();
	click(HomePage.All_tabs);
	waitForExpectedElement(HomePage.Funds);
	click(HomePage.Funds);
	LOG.info("Clicked on Funds");
	}
	
	public static void logout_CALMS() {
		LOG.info("Logging out from the classic application");
		click(HomePage.classic_link_userNavigationMenu);
		click(HomePage.classic_link_logout);
		waitForPageLoad();
		waitForExpectedElement(LoginPage.txt_username);
	}
	
	public static void Coin_tab_lightnining() throws InterruptedException {
		click(HomePage.link_Coin_fromMoreDD);
		Thread.sleep(2000);
		LOG.info("Clicked on COIN tab");
	}
	
	public static void VerifyCoin_tab_lightnining() throws InterruptedException {
		Thread.sleep(2000);
		assertEquals(isElementPresent(HomePage.link_Coin_fromMoreDD), true);
		LOG.info("Coin Tab is displayed");
	}
	
	public static void Groups_tab_lightnining() throws InterruptedException {
		click(HomePage.link_Groups_fromMoreDD);
		Thread.sleep(2000);
	}
	
	public static void clickOnNewOpptFromGlobalQuickAction() throws InterruptedException {
		click(HomePage.link_NewOpportunity_fromGlobalQuickAction);
		Thread.sleep(3000);
		LOG.info("Clicked New Oppt link");
	}
	
	public static void createOpptFromGlobalQuickAction(String timeStramp) throws InterruptedException {
		
		// Hooks.stepRecordHook("New Opportunity from Global Quick action");
		clearEnterText(OpportunityPage.text_AccountName, DataManager.getColumnData("accname"));
		click(OpportunityPage.selectAccountFromSuggestion(DataManager.getColumnData("accname")));
		clearEnterText(AccountsPage.text_opptName, DataManager.getColumnData("optyname") + timeStramp);
		click(AccountsPage.dd_InContractMAC);
		click(AccountsPage.ddSelection_InContractMAC_No);
		// clearEnterText(AccountsPage.text_TotalContractValue, "457");
		clearEnterText(AccountsPage.text_TotalContractValue, DataManager.getColumnData("amount"));
		click(AccountsPage.dd_Domain);
		click(AccountsPage.ddSelection_Domain_Mobiles);
		// clearEnterText(AccountsPage.text_description, "test desc");
		clearEnterText(AccountsPage.text_description, DataManager.getColumnData("description"));
		// Hooks.stepRecordHook("Entered details for Oppt creation");
		click(AccountsPage.btn_Save);
		Thread.sleep(3000);
	}
	
	public static void navigateToRecordIDPage(String recordID, String serverUrl) throws InterruptedException {
		openRecordIdPage(recordID, serverUrl);
	}
	
	
}
*/