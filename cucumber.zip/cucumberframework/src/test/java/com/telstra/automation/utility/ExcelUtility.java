/*package com.telstra.automation.utility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FilePermission;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.DateUtil;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelUtility {

	private static XSSFSheet WSheet;

	private static XSSFWorkbook Workbook;

	private static Cell Cell;

	private static XSSFRow Row;
	
	String[][] login=null;
	

	public static void getExcelData(String filePath, String fileName, String sheetName) throws Exception {

		try {

			// Open the Excel file

			// FilePermission permission = new FilePermission(filePath,
			// FilePermission.READ);

			FileInputStream ExcelFile = new FileInputStream(new File(filePath +File.separator+ fileName));

			// Access the required test data sheet

			Workbook = new XSSFWorkbook(ExcelFile);

			WSheet = Workbook.getSheet(sheetName);

		} catch (Exception e) {

			throw (e);

		}

	}

	// This method is to read the test data from the Excel cell, in this we are
	// passing parameters as Row num and Col num

	public static ArrayList<String> getCellData(String Org, String Profile) throws Exception {
		ArrayList<String> loginData =new  ArrayList<String>();
		ExcelUtility.Readexcel();
		
		//int col_num1=-1;
		//int col_num2=-1;
		System.out.println("Passed from Method"+Profile);
		for(int i=1;i<=WSheet.getLastRowNum();i++) {
			String org = WSheet.getRow(i).getCell(0).getStringCellValue();
				if(org.equalsIgnoreCase(Org)) {
					String profile = WSheet.getRow(i).getCell(1).getStringCellValue();
					System.out.println("Read from Excel"+profile);
					if (profile.equalsIgnoreCase(Profile)) {
						String url = WSheet.getRow(i).getCell(2).getStringCellValue();
						String userName = WSheet.getRow(i).getCell(3).getStringCellValue();
						System.out.println("Heee"+userName);
						String pwd = WSheet.getRow(i).getCell(4).getStringCellValue();
						loginData.add(url);
						loginData.add(userName);
						loginData.add(pwd);
					}
						
				}				 
			
		}
		System.out.println("Hello"+loginData);
			return loginData;
			
	}
		try {

			Cell = WSheet.getRow(RowNum).getCell(ColNum);
			 switch (Cell.getCellType())
	            {
	            case  STRING :
	            	
	            return Cell.getStringCellValue();              

	                

	            case  NUMERIC:
	            	
	            	 
	                	 return String.valueOf(Cell.getNumericCellValue());  
	                 
	            
	            default:
	                return "Cell not found";
	            }
	

		} catch (Exception e) {

			return "";

		}
		

	

	public static void Readexcel() throws Exception {
		// TODO Auto-generated method stub


		String filePath = System.getProperty("user.dir") + "\\TestData";
		//String filePath = System.getProperty("\\TestData\\TestData.xlsx");

		// Call read file method of the class to read data
		System.out.println(filePath);
		getExcelData(filePath, "TestData.xlsx", "Sheet1");

	}

}
*/